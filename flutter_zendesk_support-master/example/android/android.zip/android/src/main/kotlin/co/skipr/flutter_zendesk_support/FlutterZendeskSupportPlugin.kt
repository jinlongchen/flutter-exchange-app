package co.skipr.flutter_zendesk_support

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar
import zendesk.core.AnonymousIdentity
import zendesk.core.Identity
import zendesk.core.Zendesk
import zendesk.support.Support
import zendesk.support.guide.HelpCenterActivity

class FlutterZendeskSupportPlugin: MethodCallHandler {
  companion object {
    @JvmStatic
    fun registerWith(registrar: Registrar) {
      val channel = MethodChannel(registrar.messenger(), "flutter_zendesk_support")
      channel.setMethodCallHandler(FlutterZendeskSupportPlugin())
    }
  }

  override fun onMethodCall(call: MethodCall, result: Result) {
    if (call.method.equals("initiate")) {
        /*String url = call.argument("url");
        String appId = call.argument("appId");
        String clientId = call.argument("clientId");
        Zendesk.INSTANCE.init(mRegistrar.context(), url,
                appId,
                clientId);
        List<Long> list = new ArrayList<>();
        list.add(0, 1234L);
        list.add(0, 5678L);
        Identity identity = new AnonymousIdentity();
        Zendesk.INSTANCE.setIdentity(identity);
        Support.INSTANCE.init(Zendesk.INSTANCE);
        HelpCenterActivity.builder()
                .withArticlesForSectionIds(list)
                .show(mRegistrar.activity());
        result.success("Zendesk Initialized");
    } else {
        result.notImplemented();
    }*/
  }
}
